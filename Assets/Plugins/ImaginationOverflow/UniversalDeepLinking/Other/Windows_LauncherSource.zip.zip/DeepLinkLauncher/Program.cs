﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace DeepLinkLauncher
{
    internal class Program
    {
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr handle);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool ShowWindow(IntPtr handle, int nCmdShow);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool IsIconic(IntPtr handle);
  
       
        static void Main(string[] args)
        {
            using (var l = new QuickLog())
            {
                if (args.Length == 0)
                {
                    l.Log("No deep link arguments");
                    return;
                }

                var deepLink = args[0];
                l.Log("Deep link -> " + deepLink);

                var appToTrigger = ConfigurationManager.AppSettings.Get("Exec");
                var steamId =  ConfigurationManager.AppSettings.Get("Steam");
                var steamPath = ConfigurationManager.AppSettings.Get("SteamPath");
                var sharedFile = ConfigurationManager.AppSettings.Get("SharedFile");

                if (steamPath.EndsWith("--"))
                    steamPath = steamPath.Substring(0, steamPath.Length - 2);


                if (Ensure(appToTrigger, "Target Application", l) == false)
                    return;


                if (string.IsNullOrEmpty(steamId) == false && Ensure(steamPath, "Steam application", l) == false)
                    return;

                if (Ensure(sharedFile, "Shared File", l, true) == false)
                    return;

                var process = GetTargetProcess(appToTrigger);

                if (process == null)
                {
                    LaunchProcess(appToTrigger, steamId, steamPath, deepLink, l);
                }
                else
                {
                    File.WriteAllText(sharedFile, deepLink);

                    IntPtr handle = process.MainWindowHandle;
                    if (IsIconic(handle))
                    {
                        ShowWindow(handle, 9);
                    }

                    SetForegroundWindow(handle);

                    l.Log($"Wrote in {sharedFile} ---> {deepLink}");
                }


            }


        }

        private static void LaunchProcess(string appToTrigger, string steamId, string steamPath, string deeplink,
            QuickLog l)
        {
            if (string.IsNullOrEmpty(steamId) == false)
            {
                var steamArgs = $"-applaunch {steamId} {deeplink}";
                Process.Start(appToTrigger, steamArgs);
                l.Log($"Started steam with arguments {steamArgs}");
            }
            else
            {
                Process.Start(appToTrigger, deeplink);
                l.Log($"Started app with arguments {deeplink}");
            }
        }

        private static Process GetTargetProcess(string appToTrigger)
        {
            var procs = Process.GetProcesses();

            foreach (var process in procs)
            {
                try
                {
                    if (process.MainModule.FileName == appToTrigger)
                        return process;
                }
                catch (Exception e)
                {
                }

            }

            return null;
        }

        private static bool Ensure(string appToTrigger, string log, QuickLog l, bool skipFileCheck = false)
        {
            if (string.IsNullOrEmpty(appToTrigger))
            {
                l.Log($"{log}: not set");
                return false;
            }

            if (skipFileCheck)
                return true;

            if (File.Exists(appToTrigger) == false)
            {
                l.Log($"{log}: does not exist in {appToTrigger}");
                return false;
            }

            l.Log($"{log}: found in: {appToTrigger}");


            return true;
        }
    }

    internal class QuickLog : IDisposable
    {
        private List<string> _logs = new List<string>();
        public QuickLog()
        {

        }

        public void Log(string s)
        {
            var log = $"{DateTime.Now.ToString("g")}: {s}";
            _logs.Add(log);
            //Console.WriteLine(log);
        }

        public void Dispose()
        {
            var dir = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
            File.WriteAllLines(Path.Combine(dir, "log.txt"), _logs.ToArray());
        }
    }
}
